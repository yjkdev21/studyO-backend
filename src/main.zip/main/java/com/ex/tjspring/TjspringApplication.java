package com.ex.tjspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TjspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(TjspringApplication.class, args);
	}
}
